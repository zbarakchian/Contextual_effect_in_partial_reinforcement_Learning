classdef model_class
    %=======================================================================
    %-properties
    %=======================================================================   
    properties
        name
        description
        parameters
        index
    end
    
    %=======================================================================
    %-methods
    %=======================================================================   
    methods
        % Constructor
        %------------------------------------------------------------------
        function thismodel = model_class(name,description)
            if nargin > 0
                thismodel.name = name;
                thismodel.description = description;
            end
        end
        
        % getter
        %------------------------------------------------------------------
        function output = get.name(thismodel)
            output = thismodel.name;
        end

        function output = get.description(thismodel)
            output = thismodel.description;
        end
        
        function output = get.parameters(thismodel)
            output = thismodel.parameters;
        end
               
        function output = get.index(thismodel)
            output = thismodel.index;
        end
        
        % setter
        %------------------------------------------------------------------
        function thismodel = set.index(thismodel,indx)
            thismodel.index = indx;
        end

        % others
        %------------------------------------------------------------------        
%         function func()
%         end
%         
%         function funcCrossV()
%         end
%         
%         function simulate()
%         end
%         
%         function simulate_sbj()
%         end
%         
%         function study_params()
%         end
    end   
end

