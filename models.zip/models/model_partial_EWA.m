classdef model_partial_EWA < model_class
%==========================================================================
%-properties
%==========================================================================   
properties
end

%==========================================================================
%-methods
%==========================================================================   
methods        
%-constructor
%------------------------------------------------------------------
function thismodel = model_partial_EWA(name,description,config_fit)
%            model_partial_LI1@model_class(arg)
   if nargin > 0
        thismodel.name = name;
        thismodel.description = description;
        thismodel.parameters.name = {'beta','ro','phi'};
        thismodel.parameters.num  = length(thismodel.parameters.name);
        thismodel.parameters.lb = [0    0 0];
        thismodel.parameters.ub = [Inf  1 1];
        thismodel.parameters.prior = [1.2  1.2];%beta_dist

        inits.beta  = [0:config_fit.inits_res:1];
        inits.ro    = [0:config_fit.inits_res:1];
        inits.phi   = [0:config_fit.inits_res:1];
        initial_points = [];
        for b = inits.beta
            for r = inits.ro
                for ph = inits.phi
                    initial_points = [initial_points; [b r ph]];
                end
            end
        end
        thismodel.parameters.inits = initial_points;
   end
end

%-getteres
%--------------------------------------------------------------------------

%-likelihood function
%--------------------------------------------------------------------------       
function lik = func(thismodel,params,args)
    %params,Q,arg_learn,arg_transfe
    Q            = args.Q0;
    arg_learn    = args.arg_learn(args.t1:args.t2,:);
    arg_transfer = args.arg_transfer;
    use_prior    = args.use_prior;
    fit_transfer = args.fit_transfer;
    %--------------------
    beta   = params(1);                                                     
    ro     = params(2);
    phi    = params(3);
    %--------------------
    %remove the non-responded trials from fitting analysis
%     Indx = find(arg_learn(:,5) == 1);
%     arg_learn = arg_learn(Indx,:);           
    %--------------------           
    s = arg_learn(:,1);
    a = arg_learn(:,2);
    r = arg_learn(:,3);
    c = arg_learn(:,4);
    %--------------------                   
    N      = zeros(2 ,2); 
    lik    = 0;
    for i = 1:length(a)  
        beta_dot_dif  = beta * (Q(s(i),3-a(i)) - Q(s(i),a(i)));
        logP          = - log(1 + exp(beta_dot_dif));    
        lik           = lik + logP;                                                          

        Q(s(i),a(i))  = (phi * N(s(i),a(i)) * Q(s(i),a(i))   +  1 * r(i))/(ro * N(s(i),a(i)) + 1);                                 
        N(s(i),a(i))  =  ro * N(s(i),a(i)) + 1;
    end
    
    if(use_prior)
        beta_dist = thismodel.parameters.prior;
        
        lik =  lik + log(betapdf(beta,beta_dist(1),beta_dist(2))) ;
        lik =  lik + log(betapdf(ro  ,beta_dist(1),beta_dist(2)));
        lik =  lik + log(normpdf(phi ,beta_dist(1),beta_dist(2)));
    end
    %--------------------------------------------------------------            
    if(fit_transfer)        
        QValue(1) = Q(1,1);
        QValue(2) = Q(2,1);
        QValue(3) = Q(1,2);
        QValue(4) = Q(2,2);

        cmbs = [1 2; 1 3; 1 4; 2 3; 2 4; 3 4];
        lik_transfer  = 0;
        for cmb = 1:6
            chosen   = arg_transfer(cmb);
            if (chosen == cmbs(cmb,1))    
                unchosen = cmbs(cmb,2);
            else
                unchosen = cmbs(cmb,1);        
            end
            p   = 1/(1 + exp(beta * (QValue(unchosen)-QValue(chosen)) ));
            lik_transfer = lik_transfer + log(p); 
        end                
         lik = lik + lik_transfer;
    end
    %--------------------------------------------------------------            
    lik = -lik; 
end

%-cross validation function
%------------------------------------------------------------------
function funcCrossV(thismodel,params,args)
end

%------------------------------------------------------------------
function output = simulate(thismodel,params,args)
    arg_learn = args.arg_learn;
    Q0        = args.Q0;
    sub       = args.sub;
    model     = args.model;
    %--------------------------------------------------------------------------
    beta   = params(1);                                                     
    ro     = params(2);
    phi    = params(3);
    %-------------------------------------------------------------------------- 
    con    = arg_learn(:,1);
    stim   = arg_learn(:,2:3);
    rws    = arg_learn(:,4:5);
    %--------------------------------------------------------------------------     
    I      = find(con(:)==0);     
    if isempty(I)         
        ntrials      = length(con);     
    else
        ntrials      = I(1)-1;
    end 
    %--------------------------------------------------------------------------     
    Q                   = zeros(2,2,ntrials);        
    P                   = zeros(2,2,ntrials);        
    N                   = zeros(2,2);        
    choice_counts       = zeros(2,2);
    state_action        = zeros(ntrials,2);
    %% t = 1;
    %--------------------------------------------------------------------------
    t                   = 1;
    %--------------------------------------------------------------------------
    Q(:,:,t)            = Q0;  %p is after Q                             
    
    P(1,1,t)            = 1/(1 + exp(beta*(Q(1,2,t)-Q(1,1,t))));    
    P(1,2,t)            = 1-P(1,1,t);
    
    P(2,1,t)            = 1/(1 + exp(beta*(Q(2,2,t)-Q(2,1,t))));    
    P(2,2,t)            = 1-P(2,1,t);
    %--------------------------------------------------------------------------   
    s                   = con(t); %condition 
    a                   = choose_option(P,s,t);
    choiceCode          = return_choiceCode(s,a);
    choice_indx         = return_left_right(stim(t,1),choiceCode);
    accuracy            = return_correctness(choiceCode);   
    %--------------------------------------------------------------------------
    choice_counts(s,a)  = choice_counts(s,a) + 1;    
    state_action(t,:)   = [s a];
    %--------------------------------------------------------------------------
    sim_data            = [sub,1,t,con(t), stim(t,1),stim(t,2), choice_indx, choiceCode, rws(t,1),rws(t,2), rws(t,choice_indx), rws(t,3-choice_indx), 1, accuracy, 0];
    sim_value           = [Q(1,1,t),Q(2,1,t),Q(1,2,t),Q(2,2,t)];
    %--------------------------------------------------------------------------   
    %% t >= 2;
    for t = 2:ntrials  
        %----------------------------------------------------------------------
        Q(:,:,t)     = Q(:,:,t-1);                                 
        P(:,:,t)     = P(:,:,t-1);
        %----------------------------------------------------------------------
        Q(s,a,t)     = (phi * N(s,a) * Q(s,a,t)   +  1 * rws(t-1,choice_indx))/(ro * N(s,a) + 1);                                 
        N(s,a)       =   ro * N(s,a) + 1;
        %----------------------------------------------------------------------    
        beta_dot_dif  = beta * (Q(s,3-a,t) - Q(s,a,t));        
        P(s,a,  t)    = 1/(1 + exp(beta_dot_dif));    
        P(s,3-a,t)    = 1-P(s,a,t);
        %----------------------------------------------------------------------    
        s                   = con(t); %condition 
        a                   = choose_option(P,s,t);
        choiceCode          = return_choiceCode(s,a);
        choice_indx         = return_left_right(stim(t,1),choiceCode);
        accuracy            = return_correctness(choiceCode);   
        %----------------------------------------------------------------------
        choice_counts(s,a)  = choice_counts(s,a) + 1;    
        state_action(t,:)   = [s a];
        %----------------------------------------------------------------------
        data_row  = [sub,1,t,con(t), stim(t,1),stim(t,2), choice_indx, choiceCode, rws(t,1),rws(t,2), rws(t,choice_indx), rws(t,3-choice_indx), 1, accuracy, 0];
        sim_data  = [sim_data; data_row];
        %----------------------------------------------------------------------
        data_row  = [Q(1,1,t),Q(2,1,t),Q(1,2,t),Q(2,2,t)];
        sim_value = [sim_value; data_row];
        %----------------------------------------------------------------------    
    end
    output.data  = sim_data;
    output.value = sim_value;
end

%------------------------------------------------------------------
function output = simulate_sbj(thismodel,params,args)
    %[con,stim,rws,cho,out,cou,resp]
    arg_learn = args.arg_learn;
    Q0 = args.Q0;
    %--------------------------------------------------------------------------
    ro     = params(2);
    phi    = params(3);
    %--------------------------------------------------------------------------
    %remove the non-responded trials from fitting analysis
    Indx   = find(arg_learn(:,9) == 1);
    arg_learn   = arg_learn(Indx,:);           
    %-------------------------------------------------------------------------- 
    con    = arg_learn(:,1);    
    cho    = arg_learn(:,6);     
    out    = arg_learn(:,7);     
    %--------------------------------------------------------------------------       
    ntrials  = length(cho);
    %--------------------------------------------------------------------------       
    N        = zeros(2,2);
    Q        = zeros(2,2,ntrials);        
    Q(:,:,1) = Q0; 
    %----------------------------------------------------------------------    
    for t = 2 : ntrials  
        %----------------------------------------------------------------------    
        s            = con(t-1); 
        a            = cho(t-1);
        r            = out(t-1);
        %----------------------------------------------------------------------
        Q(:,:,t)     = Q(:,:,t-1); 

        Q(s,a,t)     = (phi * N(s,a) * Q(s,a,t-1) +  1 * r)/(ro * N(s,a) + 1);                                 
        N(s,a)       =  ro  * N(s,a) + 1;
        %----------------------------------------------------------------------    
    end
    output.Qend = Q(:,:,ntrials);
    output.Qs = Q;     
end


end   
end

